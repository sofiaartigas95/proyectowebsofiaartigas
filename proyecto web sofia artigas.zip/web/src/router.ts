import {Router} from "express"
import { createProduct } from "./config/handlers/product"

const router= Router()

//Routing
router.get('/', (req,res) =>{
    console.log('GET')
    res.json('Desde GET')
})

router.post('/', createProduct)



export default router
import server from "./server"

server.listen(4000, () => {
    console.log('REST API en el puerto 4000')
})